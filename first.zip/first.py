a = input("enter first number:")
b = input("enter second number:")


addition = int(a) + int(b)
print(addition)

mutiplication = int(a) * int(b)
print(mutiplication)

subtraction = int(a) - int(b)
print(subtraction)

divition = int(a) / int(b)
print(divition)




c = input("enter user first name:")
d = input("enter user last name:")
full_name = c + " " + d
print(full_name)
print('hello,'+full_name + " welcome.")